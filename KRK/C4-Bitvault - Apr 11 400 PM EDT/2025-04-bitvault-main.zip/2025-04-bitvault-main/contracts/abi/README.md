## What's this?

This is a place to put automatically generated ABI definitions used by TS scripts within the [script](../script/) directory.

To generate them:

```
forge build
pnpm extract-abi
```
