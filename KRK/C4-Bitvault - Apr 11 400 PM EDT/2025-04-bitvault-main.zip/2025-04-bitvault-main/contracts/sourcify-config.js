module.exports = {
  storage: {
    read: "RepositoryV1",
    writeOrWarn: [],
    writeOrErr: ["RepositoryV1"],
  },
};
