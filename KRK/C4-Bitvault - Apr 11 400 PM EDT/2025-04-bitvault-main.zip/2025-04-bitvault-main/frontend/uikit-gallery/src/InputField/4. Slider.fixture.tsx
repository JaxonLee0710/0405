"use client";

import { InputFieldFixture } from "./shared";

export default function Fixture() {
  return <InputFieldFixture fixture="slider" />;
}
