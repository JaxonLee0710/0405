"use client";

import { DropdownFixture } from "./shared";

export default function DropdownDefaultFixture() {
  return <DropdownFixture fixture="placeholder" />;
}
