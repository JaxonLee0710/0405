"use client";

import { PillButtonFixture } from "./shared";

export default function Fixture() {
  return <PillButtonFixture fixture="medium" />;
}
