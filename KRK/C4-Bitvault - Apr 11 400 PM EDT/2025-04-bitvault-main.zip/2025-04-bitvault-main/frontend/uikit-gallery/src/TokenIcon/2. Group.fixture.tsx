"use client";

import { TokenIconFixture } from "./shared";

export default function Fixture() {
  return <TokenIconFixture defaultMode="group" />;
}
