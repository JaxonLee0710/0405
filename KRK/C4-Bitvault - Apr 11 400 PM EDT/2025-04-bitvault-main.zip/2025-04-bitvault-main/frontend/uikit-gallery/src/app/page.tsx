export default function Page() {
  return (
    <div
      style={{
        display: "grid",
        placeItems: "center",
        width: "100vw",
        height: "100vh",
      }}
    >
      <h1>UI Kit Gallery</h1>
    </div>
  );
}
