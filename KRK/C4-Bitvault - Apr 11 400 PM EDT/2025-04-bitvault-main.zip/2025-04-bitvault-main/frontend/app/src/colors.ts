export const palette = {
  sky: "#405AE5",
  blue: "#121B44",
  green: "#405AE5",
  white: "#FFFFFF",
  rain: "#9EA2B8",
};
