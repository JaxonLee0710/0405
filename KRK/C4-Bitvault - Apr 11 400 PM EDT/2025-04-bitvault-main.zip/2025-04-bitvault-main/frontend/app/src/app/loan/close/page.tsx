export default function LoanClosePage() {
  return null;
}
