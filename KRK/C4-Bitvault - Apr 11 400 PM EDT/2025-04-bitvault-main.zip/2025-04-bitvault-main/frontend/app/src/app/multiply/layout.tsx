import { LeverageScreen } from "@/src/screens/LeverageScreen/LeverageScreen";

export default function Page() {
  return <LeverageScreen />;
}
