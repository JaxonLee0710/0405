export default function Page() {
  // see layout in this folder
  return null;
}
