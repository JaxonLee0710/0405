export function generateStaticParams() {
  return [
    { action: "deposit" },
    { action: "claim" },
  ];
}

export default function EarnPoolActionPage() {
  // see layout in the parent folder
  return null;
}
