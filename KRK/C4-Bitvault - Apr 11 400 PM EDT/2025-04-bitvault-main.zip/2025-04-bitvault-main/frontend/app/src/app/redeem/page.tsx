import { RedeemScreen } from "@/src/screens/RedeemScreen/RedeemScreen";

export default function Page() {
  return <RedeemScreen />;
}
