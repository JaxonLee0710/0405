import { BorrowScreen } from "@/src/screens/BorrowScreen/BorrowScreen";

export default function Page() {
  return <BorrowScreen />;
}
