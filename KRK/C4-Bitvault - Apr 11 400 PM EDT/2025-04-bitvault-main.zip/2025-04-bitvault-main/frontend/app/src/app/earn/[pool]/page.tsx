export function generateStaticParams() {
  return [
    { pool: "eth" },
    { pool: "reth" },
    { pool: "wsteth" },
  ];
}

export default function EarnPoolPage() {
  return null;
}
