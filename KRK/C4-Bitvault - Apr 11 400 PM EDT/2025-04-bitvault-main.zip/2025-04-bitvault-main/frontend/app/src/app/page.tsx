import { HomeScreen } from "@/src/screens/HomeScreen/HomeScreen";

export default function Page() {
  return <HomeScreen />;
}
