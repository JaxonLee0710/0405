import { EarnPoolsListScreen } from "@/src/screens/EarnPoolsListScreen/EarnPoolsListScreen";

export default function Page() {
  return <EarnPoolsListScreen />;
}
