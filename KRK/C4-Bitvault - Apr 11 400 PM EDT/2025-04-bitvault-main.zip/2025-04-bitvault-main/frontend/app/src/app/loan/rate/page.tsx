export default function LoanRatePage() {
  return null;
}
