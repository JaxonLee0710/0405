export default function LoanColldebtPage() {
  return null;
}
