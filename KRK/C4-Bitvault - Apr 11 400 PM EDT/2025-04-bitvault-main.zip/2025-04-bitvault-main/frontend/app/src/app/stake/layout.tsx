import { StakeScreen } from "@/src/screens/StakeScreen/StakeScreen";

export default function Layout() {
  return <StakeScreen />;
}
