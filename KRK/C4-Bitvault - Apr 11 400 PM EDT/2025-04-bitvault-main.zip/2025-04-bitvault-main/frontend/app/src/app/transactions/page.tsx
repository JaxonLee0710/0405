import { TransactionsScreen } from "@/src/screens/TransactionsScreen/TransactionsScreen";

export default function Page() {
  return <TransactionsScreen />;
}
