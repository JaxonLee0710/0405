export function generateStaticParams() {
  return [
    { collateral: "eth" },
    { collateral: "reth" },
    { collateral: "wsteth" },
  ];
}

export default function LeverageCollateralPage() {
  // see layout in parent folder
  return null;
}
