import { LoanScreen } from "@/src/screens/LoanScreen/LoanScreen";

export default function LoanPage() {
  return <LoanScreen />;
}
