export const INFINITY = "∞";
export const ARROW_RIGHT = "→";
export const NBSP = "\u00A0";
