export function Banner() {
  return null;
}

// Example banner:

// import { css } from "@/styled-system/css";
// import { AnchorTextButton } from "@liquity2/uikit";
// import Link from "next/link";

// export function Banner() {
//   return (
//     <div
//       className={css({
//         display: "flex",
//         justifyContent: "center",
//         alignItems: "center",
//         maxWidth: "100%",
//         width: "100%",
//         height: 40,
//         textAlign: "center",
//         color: "#fff",
//         background: "#1C1D4F",
//       })}
//     >
//       <div
//         className={css({
//           width: "100%",
//           maxWidth: 1092,
//         })}
//       >
//         Banner content goes here. Here is a{" "}
//         <Link
//           href="https://example.com"
//           passHref
//           legacyBehavior
//         >
//           <AnchorTextButton
//             external
//             label="link example"
//             className={css({ color: "inherit" })}
//           />
//         </Link>.
//       </div>
//     </div>
//   );
// }
