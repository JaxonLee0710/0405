module.exports = {
  root: true,
  extends: ['base']
};
