# @staking/contracts

## 1.0.0

### Major Changes

- 885b3215e: feat(staking): work contract
